@extends('layout.master')

@section('title', 'Add Transaction')

@section('content')

    <div class="content-page">
        <div class="content">
            <div class="container-fluid">

                <!-- TOP BAR -->
                <div class="py-3 d-flex align-items-center justify-content-between">
                    <h4 class="fs-18 fw-semibold m-0">Add Transaction</h4>
                    <a href="{{ route('transaction.index') }}" class="btn btn-outline-secondary btn-sm">
                        <i class="mdi mdi-arrow-left me-1"></i> Back
                    </a>
                </div>

                <!-- ERRORS -->
                @if ($errors->any())
                    <div class="alert alert-danger alert-dismissible fade show">
                        <ul class="mb-0">
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                @endif

                <div class="card">
                    <div class="card-body">

                        <form action="{{ route('transaction.store') }}" method="POST" enctype="multipart/form-data">
                            @csrf

                            <div class="row">

                                <!-- Booking For -->
                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-medium">Booking For <span
                                            class="text-danger">*</span></label>
                                    <select name="booking_for" id="booking_for"
                                        class="form-select @error('booking_for') is-invalid @enderror" required>
                                        <option value="client"
                                            {{ old('booking_for', 'client') == 'client' ? 'selected' : '' }}>Client
                                        </option>
                                        <option value="company" {{ old('booking_for') == 'company' ? 'selected' : '' }}>
                                            Company</option>
                                    </select>
                                    @error('booking_for')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <!-- Client -->
                                <div class="col-md-6 mb-3" id="client_wrapper">
                                    <label class="form-label fw-medium">Client <span class="text-danger">*</span></label>
                                    <select name="client_id" id="client_id"
                                        class="form-select @error('client_id') is-invalid @enderror">
                                        <option value="">-- Select Client --</option>
                                        @foreach ($clients as $client)
                                            <option value="{{ $client->id }}"
                                                {{ old('client_id') == $client->id ? 'selected' : '' }}>
                                                {{ $client->name }}
                                            </option>
                                        @endforeach
                                    </select>
                                    @error('client_id')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <!-- Company -->
                                <div class="col-md-6 mb-3 d-none" id="company_wrapper">
                                    <label class="form-label fw-medium">Company <span class="text-danger">*</span></label>
                                    <select name="company_id" id="company_id"
                                        class="form-select @error('company_id') is-invalid @enderror">
                                        <option value="">-- Select Company --</option>
                                        @foreach ($companies as $company)
                                            <option value="{{ $company->id }}"
                                                {{ old('company_id') == $company->id ? 'selected' : '' }}>
                                                {{ $company->company_name ?? $company->name }}
                                            </option>
                                        @endforeach
                                    </select>
                                    @error('company_id')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="col-md-6 mb-3" id="booking_wrapper">
                                    <label class="form-label fw-medium">
                                        Select Booking <span class="text-danger">*</span>
                                    </label>
                                    <select name="booking_id" id="booking_id"
                                        class="form-select @error('booking_id') is-invalid @enderror" required>
                                        <option value="">-- Select Client/Company first --</option>
                                    </select>
                                    @error('booking_id')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <!-- Hidden source list of all bookings, used by JS to build the visible dropdown above -->
                                <div style="display:none;">
                                    <select id="all_bookings_source">
                                        @foreach ($bookings as $booking)
                                            <option value="{{ $booking->id }}" data-client-id="{{ $booking->client_id }}"
                                                data-company-id="{{ $booking->company_id }}"
                                                data-total="{{ $booking->total_amount }}"
                                                data-balance="{{ $booking->balance }}"
                                                data-package="{{ $booking->package_type }} {{ $booking->package_year }}">
                                                #{{ $booking->id }} — {{ $booking->package_type }}
                                                {{ $booking->package_year }} | Total:
                                                {{ number_format($booking->total_amount) }} | Balance:
                                                {{ number_format($booking->balance) }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>

                                <!-- Payment Type -->
                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-medium">Payment Type <span
                                            class="text-danger">*</span></label>
                                    <select name="payment_type"
                                        class="form-select @error('payment_type') is-invalid @enderror" required>
                                        <option value="">-- Select --</option>
                                        <option value="cash" {{ old('payment_type') == 'cash' ? 'selected' : '' }}>Cash
                                        </option>
                                        <option value="bank_transfer"
                                            {{ old('payment_type') == 'bank_transfer' ? 'selected' : '' }}>Bank Transfer
                                        </option>
                                        <option value="cheque" {{ old('payment_type') == 'cheque' ? 'selected' : '' }}>
                                            Cheque</option>
                                        <option value="online" {{ old('payment_type') == 'online' ? 'selected' : '' }}>
                                            Online</option>
                                    </select>
                                    @error('payment_type')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <!-- Amount (PKR) & ROE Currency Conversion -->
                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-medium">Amount (PKR) <span
                                            class="text-danger">*</span></label>
                                    <input type="number" step="0.01" name="amount" id="tx_amount" value="{{ old('amount') }}"
                                        class="form-control @error('amount') is-invalid @enderror" placeholder="0.00"
                                        min="1" required>
                                    @error('amount')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-medium">Exchange Rate (ROE: 1 SAR in PKR)</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light">1 SAR =</span>
                                        <input type="number" step="0.0001" name="exchange_rate" id="tx_roe" value="{{ old('exchange_rate', '75.00') }}"
                                            class="form-control" placeholder="75.00">
                                        <span class="input-group-text">PKR</span>
                                    </div>
                                    <small class="text-success fw-semibold mt-1 d-block" id="tx_sar_hint">
                                        ≈ 0.00 SAR
                                    </small>
                                </div>

                                <!-- Payment Date -->
                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-medium">Payment Date <span
                                            class="text-danger">*</span></label>
                                    <input type="date" name="payment_date"
                                        value="{{ old('payment_date', date('Y-m-d')) }}"
                                        class="form-control @error('payment_date') is-invalid @enderror" required>
                                    @error('payment_date')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <!-- Reference Number -->
                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-medium">Reference / Cheque No</label>
                                    <input type="text" name="reference_number" value="{{ old('reference_number') }}"
                                        class="form-control @error('reference_number') is-invalid @enderror"
                                        placeholder="TXN-123 / Cheque No">
                                    @error('reference_number')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <!-- Proof of Payment -->
                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-medium">
                                        Proof of Payment
                                        <small class="text-muted">(JPG, PNG, PDF — Max 2MB)</small>
                                    </label>
                                    <input type="file" name="proof_of_payment"
                                        class="form-control @error('proof_of_payment') is-invalid @enderror"
                                        accept=".jpg,.jpeg,.png,.pdf">
                                    @error('proof_of_payment')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <!-- Status -->
                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-medium">Status <span class="text-danger">*</span></label>
                                    <select name="status" class="form-select @error('status') is-invalid @enderror"
                                        required>
                                        <option value="confirmed"
                                            {{ old('status', 'confirmed') == 'confirmed' ? 'selected' : '' }}>Confirmed
                                        </option>
                                        <option value="pending" {{ old('status') == 'pending' ? 'selected' : '' }}>Pending
                                        </option>
                                        <option value="rejected" {{ old('status') == 'rejected' ? 'selected' : '' }}>
                                            Rejected</option>
                                    </select>
                                    @error('status')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <!-- Notes -->
                                <div class="col-12 mb-4">
                                    <label class="form-label fw-medium">Notes</label>
                                    <textarea name="notes" rows="3" class="form-control @error('notes') is-invalid @enderror"
                                        placeholder="Optional remarks...">{{ old('notes') }}</textarea>
                                    @error('notes')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                            </div>

                            <div class="d-flex gap-2">
                                <button type="submit" class="btn btn-primary">
                                    <i class="mdi mdi-content-save me-1"></i> Save Transaction
                                </button>
                                <a href="{{ route('transaction.index') }}" class="btn btn-outline-secondary">
                                    Cancel
                                </a>
                            </div>

                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const bookingForSelect = document.getElementById('booking_for');
            const clientWrapper = document.getElementById('client_wrapper');
            const companyWrapper = document.getElementById('company_wrapper');
            const clientSelect = document.getElementById('client_id');
            const companySelect = document.getElementById('company_id');
            const bookingSelect = document.getElementById('booking_id');
            const sourceSelect = document.getElementById('all_bookings_source');

            // Build a plain JS array of all bookings from the hidden source select
            const allBookings = Array.from(sourceSelect.options).map(opt => ({
                value: opt.value,
                clientId: opt.dataset.clientId,
                companyId: opt.dataset.companyId,
                label: opt.textContent,
            }));

            // Old value (used when validation fails and the form re-renders)
            const oldBookingId = "{{ old('booking_id') }}";

            // Rebuild the visible booking dropdown based on selected client/company
            function filterBookings(type, id) {
                bookingSelect.innerHTML = '';

                if (!id) {
                    const placeholder = document.createElement('option');
                    placeholder.value = '';
                    placeholder.textContent = '-- Select Client/Company first --';
                    bookingSelect.appendChild(placeholder);
                    return;
                }

                const matches = allBookings.filter(b =>
                    type === 'company' ? b.companyId === id : b.clientId === id
                );

                const placeholder = document.createElement('option');
                placeholder.value = '';
                placeholder.textContent = matches.length ?
                    '-- Select Booking --' :
                    '-- No booking found for this selection --';
                bookingSelect.appendChild(placeholder);

                matches.forEach(b => {
                    const opt = document.createElement('option');
                    opt.value = b.value;
                    opt.textContent = b.label;
                    bookingSelect.appendChild(opt);
                });

                if (oldBookingId && matches.some(b => b.value === oldBookingId)) {
                    bookingSelect.value = oldBookingId;
                }
            }

            function toggleFields() {
                if (bookingForSelect.value === 'company') {
                    clientWrapper.classList.add('d-none');
                    companyWrapper.classList.remove('d-none');
                    clientSelect.value = '';
                    clientSelect.removeAttribute('required');
                    companySelect.setAttribute('required', 'required');
                    filterBookings('company', companySelect.value);
                } else {
                    companyWrapper.classList.add('d-none');
                    clientWrapper.classList.remove('d-none');
                    companySelect.value = '';
                    companySelect.removeAttribute('required');
                    clientSelect.setAttribute('required', 'required');
                    filterBookings('client', clientSelect.value);
                }
            }

            bookingForSelect.addEventListener('change', toggleFields);
            clientSelect.addEventListener('change', function() {
                filterBookings('client', this.value);
            });
            companySelect.addEventListener('change', function() {
                filterBookings('company', this.value);
            });

            toggleFields();

            // Live SAR Equivalent calculation
            const txAmt = document.getElementById('tx_amount');
            const txRoe = document.getElementById('tx_roe');
            const txHint = document.getElementById('tx_sar_hint');
            function calcTxSar() {
                const pkr = parseFloat(txAmt?.value) || 0;
                const roe = parseFloat(txRoe?.value) || 75;
                if (pkr > 0 && roe > 0) {
                    const sar = (pkr / roe).toFixed(2);
                    if (txHint) txHint.textContent = `≈ ${sar} SAR (at 1 SAR = ${roe} PKR)`;
                } else {
                    if (txHint) txHint.textContent = '≈ 0.00 SAR';
                }
            }
            if (txAmt) txAmt.addEventListener('input', calcTxSar);
            if (txRoe) txRoe.addEventListener('input', calcTxSar);
            calcTxSar();
        });
    </script>

@endsection
